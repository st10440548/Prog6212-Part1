using System;
using System.ComponentModel.DataAnnotations;
namespace CMS.Models
{
    public class Claim
    {
        public int ClaimId { get; set; }
        [Required] public int LecturerId { get; set; }
        public Lecturer Lecturer { get; set; }
        [Required] public decimal HoursWorked { get; set; }
        [Required] public decimal HourlyRate { get; set; }
        public decimal TotalAmount => HoursWorked * HourlyRate;
        public string Notes { get; set; }
        public string Status { get; set; } = "Pending";
        public DateTime SubmissionDate { get; set; } = DateTime.UtcNow;
    }
}
