using Microsoft.AspNetCore.Mvc;
using CMS.Data;
using CMS.Models;
using System.Threading.Tasks;

namespace CMS.Controllers
{
    public class LecturerController : Controller
    {
        private readonly ApplicationDbContext _context;
        public LecturerController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Lecturer/Submit
        public IActionResult Submit()
        {
            return View();
        }

        // POST: Lecturer/Submit
        [HttpPost]
        public async Task<IActionResult> Submit(Claim claim)
        {
            if (ModelState.IsValid)
            {
                _context.Claims.Add(claim);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Submitted));
            }
            return View(claim);
        }

        public IActionResult Submitted()
        {
            return View();
        }
    }
}
