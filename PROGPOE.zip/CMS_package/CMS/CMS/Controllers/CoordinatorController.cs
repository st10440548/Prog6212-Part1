using Microsoft.AspNetCore.Mvc;
using CMS.Data;
using System.Linq;
using System.Threading.Tasks;

namespace CMS.Controllers
{
    public class CoordinatorController : Controller
    {
        private readonly ApplicationDbContext _context;
        public CoordinatorController(ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult Pending()
        {
            var pending = _context.Claims.Where(c => c.Status == "Pending").ToList();
            return View(pending);
        }

        [HttpPost]
        public async Task<IActionResult> Approve(int id)
        {
            var claim = _context.Claims.FirstOrDefault(c => c.ClaimId == id);
            if (claim != null)
            {
                claim.Status = "Approved";
                _context.Approvals.Add(new Models.Approval { ClaimId = claim.ClaimId, ApprovedBy = "Coordinator", Decision = "Approved" });
                await _context.SaveChangesAsync();
            }
            return RedirectToAction(nameof(Pending));
        }

        [HttpPost]
        public async Task<IActionResult> Reject(int id)
        {
            var claim = _context.Claims.FirstOrDefault(c => c.ClaimId == id);
            if (claim != null)
            {
                claim.Status = "Rejected";
                _context.Approvals.Add(new Models.Approval { ClaimId = claim.ClaimId, ApprovedBy = "Coordinator", Decision = "Rejected" });
                await _context.SaveChangesAsync();
            }
            return RedirectToAction(nameof(Pending));
        }
    }
}
