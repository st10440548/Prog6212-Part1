Contract Monthly Claim System (CMS) - Submission Package

Contents:
- CMS/                 -> ASP.NET Core MVC project skeleton (non-built)
- Docs/                -> Project documentation (Word .docx) and implementation notes
- UML/                 -> UML class diagram image (PNG)
- SqlScripts/          -> SQL Server schema creation script
- Tests/               -> Unit test scaffold (xUnit)
- LICENSE.txt

Notes:
- This is a ready-to-edit Visual Studio / dotnet project skeleton. To run:
  1. Open the CMS.sln in Visual Studio or use `dotnet restore` then `dotnet build`.
  2. Update the connection string in CMS/appsettings.json to point to your SQL Server instance.
- The project intentionally implements only the requested features (claim submission, approvals, uploads skeleton).
