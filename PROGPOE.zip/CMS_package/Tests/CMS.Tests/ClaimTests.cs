using System;
using Xunit;
using CMS.Models;

namespace CMS.Tests
{
    public class ClaimTests
    {
        [Fact]
        public void TotalAmount_IsCalculatedCorrectly()
        {
            var c = new Claim { HoursWorked = 10, HourlyRate = 50 };
            Assert.Equal(500, c.TotalAmount);
        }
    }
}
